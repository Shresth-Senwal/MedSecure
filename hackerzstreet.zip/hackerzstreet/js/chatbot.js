/**
 * MedSecure Chatbot Module
 * 
 * Implements a chatbot using Google's Gemini API to provide medical assistance.
 */

const Chatbot = {
    // Configuration
    API_KEY: 'AIzaSyD_2EgFq-zXRf25CWGMzhKIAwoQtp5O5SY',
    API_URL: 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent',
    USE_TEST_MODE: false, // Set to true for testing without API calls
    
    // Chat history
    conversations: [],
    
    // Fallback responses when API is unavailable
    fallbackResponses: [
        "I'm here to help you manage your medical records and answer basic health questions.",
        "You can use MedSecure to securely store, share, and access your medical records.",
        "For medical emergencies, please contact your healthcare provider or emergency services.",
        "The Dashboard shows you an overview of your records and recent activity.",
        "You can upload medical records by clicking on 'Upload Record' in the Records section.",
        "MedSecure is HIPAA-compliant, ensuring your medical data remains private and secure.",
        "You can share specific records with healthcare providers through the Share section.",
        "Please note that I'm not a replacement for professional medical advice."
    ],
    
    /**
     * Initialize the chatbot
     */
    init: function() {
        this.bindEvents();
        console.log('Chatbot initialized');
        
        // Self-test to console
        this.testConnection();
    },
    
    /**
     * Bind event listeners
     */
    bindEvents: function() {
        const sendButton = document.getElementById('send-message');
        const chatInput = document.getElementById('chat-input');
        const chatMessages = document.getElementById('chat-messages');
        
        if (sendButton && chatInput) {
            // Send message on button click
            sendButton.addEventListener('click', () => {
                this.sendMessage();
                // Return focus to input after sending
                setTimeout(() => chatInput.focus(), 0);
            });
            
            // Send message on Enter key (but allow Shift+Enter for new line)
            chatInput.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    this.sendMessage();
                }
            });
            
            // Prevent focus on message area which can cause caret issues
            if (chatMessages) {
                chatMessages.addEventListener('mousedown', (e) => {
                    // Allow selection but prevent focus
                    if (e.target.tagName !== 'BUTTON' && e.target.tagName !== 'A') {
                        e.preventDefault();
                        // If selection is intended, allow it
                        if (window.getSelection().toString() === '') {
                            // Focus back to input unless user is selecting text
                            chatInput.focus();
                        }
                    }
                });
            }
            
            // Set initial focus to input when chat tab is activated
            document.querySelector('.nav-link[data-view="chatbot"]')?.addEventListener('click', () => {
                setTimeout(() => chatInput.focus(), 100);
            });
        }
    },
    
    /**
     * Send user message to the chatbot
     */
    sendMessage: function() {
        const chatInput = document.getElementById('chat-input');
        const message = chatInput.value.trim();
        
        if (!message) return;
        
        // Add user message to chat
        this.addMessageToChat('user', message);
        
        // Clear input
        chatInput.value = '';
        
        // Add message to conversation history - with proper formatting for Gemini 2.0 API
        this.conversations.push({
            role: 'user',
            parts: [{ text: message }]
        });
        
        // Show thinking indicator
        this.showThinkingIndicator();
        
        console.log("User message:", message);
        console.log("Current conversation history:", this.conversations);
        
        // Get response from Gemini API
        this.getGeminiResponse(message);
    },
    
    /**
     * Get response from Gemini API
     * @param {string} message - User message
     */
    getGeminiResponse: function(message) {
        // Keep focus in chat input
        const chatInput = document.getElementById('chat-input');
        if (chatInput) chatInput.focus();
        
        // If in test mode, use fallback responses instead of API
        if (this.USE_TEST_MODE) {
            console.log("Running in test mode - using fallback responses");
            setTimeout(() => {
                this.removeThinkingIndicator();
                const response = this.getFallbackResponse(message);
                this.addMessageToChat('assistant', response);
                
                // Add to conversation history
                this.conversations.push({
                    role: 'model',
                    parts: [{ text: response }]
                });
            }, 1000);
            return;
        }
        
        // Try to use offline mode if the query contains certain keywords
        const offlineTriggers = ['help', 'guide', 'upload', 'share', 'record', 'dashboard'];
        const isOfflineQueryPossible = offlineTriggers.some(trigger => message.toLowerCase().includes(trigger));
        
        // Build the request context with history for conversation continuity
        const systemContext = "You are a medical assistant chatbot for MedSecure, a HIPAA-compliant medical records platform. " +
            "Provide helpful, accurate information about medical topics, but remember to include disclaimers that you're not " +
            "a substitute for professional medical advice. You can also help users navigate the MedSecure platform. " + 
            "Keep responses concise, professional, and easy to understand.";
        
        // For beta API, Gemini doesn't support system role directly so we add as first user message
        let contents = [];
        
        // First add the system message as a user message if this is the first message
        if (this.conversations.length <= 1) {
            contents.push({
                role: "user",
                parts: [{ text: systemContext }]
            });
            
            contents.push({
                role: "model",
                parts: [{ text: "I understand. I'll act as a medical assistant for MedSecure, providing helpful information while noting I'm not a substitute for professional medical advice." }]
            });
        }
        
        // Add conversation history
        this.conversations.forEach(msg => {
            contents.push({
                role: msg.role === 'user' ? 'user' : 'model',
                parts: msg.parts
            });
        });
        
        console.log("Sending API request with contents:", contents);
        
        const requestBody = {
            contents: contents,
            generationConfig: {
                temperature: 0.2,
                topK: 32,
                topP: 0.95,
                maxOutputTokens: 800,
            }
        };
        
        // Make request to Gemini API with proper URL construction
        const apiUrl = `${this.API_URL}?key=${this.API_KEY}`;
        console.log("API URL (without key):", this.API_URL);
        
        fetch(apiUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(requestBody)
        })
        .then(response => {
            console.log("API Response Status:", response.status);
            
            if (!response.ok) {
                return response.text().then(text => {
                    try {
                        // Try to parse the error response as JSON
                        const errorData = JSON.parse(text);
                        console.error("API Error Response:", errorData);
                        throw new Error(`HTTP error! Status: ${response.status}, Message: ${errorData.error?.message || 'Unknown error'}`);
                    } catch (e) {
                        // If parsing fails, use the raw text
                        console.error("API Error Raw Response:", text);
                        throw new Error(`HTTP error! Status: ${response.status}, Raw response: ${text.substring(0, 100)}...`);
                    }
                });
            }
            return response.json();
        })
        .then(data => {
            console.log("Gemini 2.0 API Response:", data); // Debug log
            
            // Remove thinking indicator
            this.removeThinkingIndicator();
            
            // Error handling for malformed responses
            if (!data.candidates || !data.candidates[0] || !data.candidates[0].content || !data.candidates[0].content.parts) {
                console.error("Unexpected API response format:", data);
                throw new Error("The API response doesn't contain the expected data structure");
            }
            
            // Get the response text
            const responseText = data.candidates[0].content.parts[0].text;
            
            // Add response to chat
            this.addMessageToChat('assistant', responseText);
            
            // Add to conversation history
            this.conversations.push({
                role: 'model',
                parts: [{ text: responseText }]
            });
        })
        .catch(error => {
            console.error('Error calling Gemini 2.0 API:', error);
            
            // Remove thinking indicator
            this.removeThinkingIndicator();
            
            // Provide more specific error message
            let errorMessage = '';
            
            if (error.message && error.message.includes('429')) {
                errorMessage = "I'm currently experiencing high demand. Please try again in a few moments.";
            } else if (error.message && error.message.includes('403')) {
                errorMessage = "There seems to be an authentication issue with my service. The team has been notified.";
            } else if (error.message && error.message.includes('404')) {
                errorMessage = "The AI service endpoint couldn't be found. This could be a temporary issue or a configuration problem.";
            } else if (error.message && error.message.includes("doesn't contain the expected data structure")) {
                errorMessage = "I received an unexpected response format. This has been logged for investigation.";
            } else if (isOfflineQueryPossible) {
                // Use fallback response for navigation/help questions when API is down
                errorMessage = this.getFallbackResponse(message);
            } else {
                errorMessage = "I'm having trouble connecting to my knowledge base right now. Please try again later, or ask me about using the MedSecure platform.";
            }
            
            // Log full error details to console
            console.log('API Error details:', error);
            
            // Add error message to chat
            this.addMessageToChat('assistant', errorMessage);
        });
    },
    
    /**
     * Get a fallback response when API is unavailable
     * @param {string} query - User's message
     * @returns {string} Fallback response
     */
    getFallbackResponse: function(query) {
        // Check for common queries and provide specific responses
        query = query.toLowerCase();
        
        if (query.includes('upload') || query.includes('add record')) {
            return "To upload a medical record, go to the Records tab and click the 'Upload New Record' button. You can upload PDFs, images, and other document formats.";
        }
        
        if (query.includes('share') || query.includes('send')) {
            return "You can share your medical records securely with healthcare providers. Navigate to the Share tab, select the records you want to share, and provide the recipient's email address.";
        }
        
        if (query.includes('password') || query.includes('security')) {
            return "You can update your password and security settings in the Settings tab. We recommend using a strong, unique password and enabling two-factor authentication for additional security.";
        }
        
        if (query.includes('help') || query.includes('how to')) {
            return "MedSecure allows you to securely manage your medical records. You can upload, view, and share records with healthcare providers. For specific guidance, please ask about the feature you need help with.";
        }
        
        // If no specific match, return a random fallback response
        const randomIndex = Math.floor(Math.random() * this.fallbackResponses.length);
        return this.fallbackResponses[randomIndex];
    },
    
    /**
     * Add message to chat UI
     * @param {string} role - 'user' or 'assistant'
     * @param {string} text - Message text
     */
    addMessageToChat: function(role, text) {
        const chatMessages = document.getElementById('chat-messages');
        const chatInput = document.getElementById('chat-input');
        
        if (!chatMessages) return;
        
        const messageElement = document.createElement('div');
        messageElement.className = `message ${role}`;
        
        const currentTime = new Date();
        const formattedTime = currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        
        messageElement.innerHTML = `
            <div class="message-content">
                <p>${this.formatMessageText(text)}</p>
                <div class="message-time">${formattedTime}</div>
            </div>
        `;
        
        chatMessages.appendChild(messageElement);
        
        // Scroll to bottom (using smooth scrolling to prevent focus issues)
        chatMessages.scrollTo({
            top: chatMessages.scrollHeight,
            behavior: 'smooth'
        });
        
        // Keep focus in chat input
        if (chatInput) setTimeout(() => chatInput.focus(), 100);
    },
    
    /**
     * Format message text with basic markdown
     * @param {string} text - Message text
     * @returns {string} Formatted text
     */
    formatMessageText: function(text) {
        // Replace newlines with <br>
        text = text.replace(/\n/g, '<br>');
        
        // Format bold text: **text** or __text__
        text = text.replace(/(\*\*|__)(.*?)\1/g, '<strong>$2</strong>');
        
        // Format italic text: *text* or _text_
        text = text.replace(/(\*|_)(.*?)\1/g, '<em>$2</em>');
        
        // Format code: `code`
        text = text.replace(/`(.*?)`/g, '<code>$1</code>');
        
        // Format lists
        const lines = text.split('<br>');
        let inList = false;
        let listType = '';
        
        for (let i = 0; i < lines.length; i++) {
            // Unordered list items
            if (lines[i].trim().match(/^[*\-•]\s+(.+)$/)) {
                if (!inList || listType !== 'ul') {
                    lines[i] = inList ? '</ul><ul><li>' + lines[i].replace(/^[*\-•]\s+/, '') + '</li>' : '<ul><li>' + lines[i].replace(/^[*\-•]\s+/, '') + '</li>';
                    inList = true;
                    listType = 'ul';
                } else {
                    lines[i] = '<li>' + lines[i].replace(/^[*\-•]\s+/, '') + '</li>';
                }
            }
            // Ordered list items
            else if (lines[i].trim().match(/^\d+\.\s+(.+)$/)) {
                if (!inList || listType !== 'ol') {
                    lines[i] = inList ? '</ol><ol><li>' + lines[i].replace(/^\d+\.\s+/, '') + '</li>' : '<ol><li>' + lines[i].replace(/^\d+\.\s+/, '') + '</li>';
                    inList = true;
                    listType = 'ol';
                } else {
                    lines[i] = '<li>' + lines[i].replace(/^\d+\.\s+/, '') + '</li>';
                }
            }
            // End list if line is not a list item
            else if (inList && lines[i].trim() !== '') {
                lines[i] = listType === 'ul' ? '</ul>' + lines[i] : '</ol>' + lines[i];
                inList = false;
            }
        }
        
        // Close any open list
        if (inList) {
            lines.push(listType === 'ul' ? '</ul>' : '</ol>');
        }
        
        return lines.join('<br>');
    },
    
    /**
     * Show thinking indicator
     */
    showThinkingIndicator: function() {
        const chatMessages = document.getElementById('chat-messages');
        const chatInput = document.getElementById('chat-input');
        
        if (!chatMessages) return;
        
        const thinkingElement = document.createElement('div');
        thinkingElement.className = 'message assistant';
        thinkingElement.id = 'thinking-indicator';
        
        thinkingElement.innerHTML = `
            <div class="message-content message-thinking">
                <div class="thinking-dot"></div>
                <div class="thinking-dot"></div>
                <div class="thinking-dot"></div>
            </div>
        `;
        
        chatMessages.appendChild(thinkingElement);
        
        // Scroll to bottom smoothly
        chatMessages.scrollTo({
            top: chatMessages.scrollHeight,
            behavior: 'smooth'
        });
        
        // Keep focus in chat input
        if (chatInput) setTimeout(() => chatInput.focus(), 50);
    },
    
    /**
     * Remove thinking indicator
     */
    removeThinkingIndicator: function() {
        const thinkingIndicator = document.getElementById('thinking-indicator');
        
        if (thinkingIndicator) {
            thinkingIndicator.remove();
        }
    },
    
    /**
     * Test API connection and log results
     */
    testConnection: function() {
        console.log("Testing Gemini API connection with URL:", this.API_URL);
        
        const testMessage = "This is a test. Please respond with 'OK' if you receive this message.";
        
        // Simple fetch test to verify connectivity
        fetch(`${this.API_URL}?key=${this.API_KEY}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                contents: [{
                    role: "user",
                    parts: [{ text: testMessage }]
                }],
                generationConfig: {
                    temperature: 0.1,
                    maxOutputTokens: 100
                }
            })
        })
        .then(response => {
            console.log("Test API Response Status:", response.status);
            if (response.ok) {
                console.log("Test API connectivity successful!");
                return response.json();
            } else {
                console.error("Test failed - API connectivity issue");
                return response.text().then(text => {
                    console.error("Error details:", text);
                });
            }
        })
        .then(data => {
            console.log("Test API Response:", data);
        })
        .catch(error => {
            console.error("Test failed - API request error:", error);
        });
    }
}; 