/**
 * Authentication module for MedSecure
 * 
 * Handles user registration, login, and session management.
 */

const Auth = {
    /**
     * Initialize the authentication system
     */
    init: function() {
        // Check if user is already logged in
        const currentUser = DataStore.getCurrentUser();
        
        if (currentUser) {
            this.showApp(currentUser);
        } else {
            this.showAuth();
        }
        
        // Add event listeners
        this.bindEvents();
        
        // Ensure input fields can be focused and typed in
        this.ensureInputsFocusable();
    },
    
    /**
     * Make sure all inputs are properly focusable and can receive text input
     */
    ensureInputsFocusable: function() {
        const inputs = document.querySelectorAll('input, select, textarea');
        
        inputs.forEach(input => {
            // Remove any problematic event listeners or attributes
            input.removeAttribute('readonly');
            input.removeAttribute('disabled');
            
            // Ensure the input has appropriate z-index and is clickable
            input.style.position = 'relative';
            input.style.zIndex = '10';
            
            // Add a click handler to ensure focus
            input.addEventListener('click', function(e) {
                this.focus();
                e.stopPropagation();
            });
        });
        
        // Add specific handler for the login form
        const loginForm = document.getElementById('login-form');
        if (loginForm) {
            const loginEmail = document.getElementById('login-email');
            const loginPassword = document.getElementById('login-password');
            
            if (loginEmail) {
                loginEmail.addEventListener('focus', function() {
                    this.select();
                });
            }
            
            if (loginPassword) {
                loginPassword.addEventListener('focus', function() {
                    this.select();
                });
            }
        }
        
        // Add specific handler for the registration form
        const registerForm = document.getElementById('register-form');
        if (registerForm) {
            const regInputs = registerForm.querySelectorAll('input');
            regInputs.forEach(input => {
                input.addEventListener('focus', function() {
                    this.select();
                });
            });
        }
    },
    
    /**
     * Attach event listeners for auth-related functionality
     */
    bindEvents: function() {
        // Tab switching
        const tabButtons = document.querySelectorAll('.tab-btn');
        tabButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                const targetTab = btn.getAttribute('data-tab');
                this.switchTab(targetTab);
            });
        });
        
        // Form submissions
        const loginForm = document.getElementById('login');
        const registerForm = document.getElementById('register');
        
        if (loginForm) {
            loginForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleLogin();
            });
        }
        
        if (registerForm) {
            registerForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleRegistration();
            });
        }
        
        // Logout
        const logoutBtn = document.getElementById('logout-btn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', () => {
                this.handleLogout();
            });
        }
    },
    
    /**
     * Switch between login and registration tabs
     * @param {string} tab - Tab to switch to ('login' or 'register')
     */
    switchTab: function(tab) {
        // Update tab buttons
        const tabButtons = document.querySelectorAll('.tab-btn');
        tabButtons.forEach(btn => {
            if (btn.getAttribute('data-tab') === tab) {
                btn.classList.add('active');
            } else {
                btn.classList.remove('active');
            }
        });
        
        // Update form containers
        const forms = document.querySelectorAll('.form-container');
        forms.forEach(form => {
            if (form.id === `${tab}-form`) {
                form.classList.add('active');
            } else {
                form.classList.remove('active');
            }
        });
    },
    
    /**
     * Handle login form submission
     */
    handleLogin: function() {
        const emailInput = document.getElementById('login-email');
        const passwordInput = document.getElementById('login-password');
        
        const email = emailInput.value.trim();
        const password = passwordInput.value;
        
        try {
            // Find user by email
            const users = DataStore.getUsers();
            const user = users.find(u => u.email === email);
            
            if (!user) {
                console.log('User not found:', email);
                alert('Invalid email or password');
                return;
            }
            
            // Simplified password check
            const expectedHash = password + '_hashed';
            
            if (expectedHash === user.passwordHash) {
                // Login successful
                DataStore.setCurrentUser(user.id);
                this.showApp(user);
            } else {
                // Login failed
                console.log('Invalid password for user:', email);
                alert('Invalid email or password');
            }
        } catch (error) {
            console.error('Login error:', error);
            alert('An error occurred during login');
        }
    },
    
    /**
     * Handle registration form submission
     */
    handleRegistration: function() {
        const nameInput = document.getElementById('reg-name');
        const emailInput = document.getElementById('reg-email');
        const roleInput = document.getElementById('reg-role');
        const passwordInput = document.getElementById('reg-password');
        const confirmPasswordInput = document.getElementById('reg-confirm-password');
        
        const name = nameInput.value.trim();
        const email = emailInput.value.trim();
        const role = roleInput.value;
        const password = passwordInput.value;
        const confirmPassword = confirmPasswordInput.value;
        
        // Validate inputs
        if (!name || !email || !role || !password) {
            alert('Please fill in all fields');
            return;
        }
        
        if (password !== confirmPassword) {
            alert('Passwords do not match');
            return;
        }
        
        try {
            // Check if email already exists
            const users = DataStore.getUsers();
            const existingUser = users.find(u => u.email === email);
            
            if (existingUser) {
                alert('Email is already registered');
                return;
            }
            
            // Simplified password hash
            const passwordHash = password + '_hashed';
            
            // Create user object
            const userId = 'user_' + Date.now();
            const user = {
                id: userId,
                name,
                email,
                role,
                passwordHash,
                createdAt: new Date().toISOString(),
                encryptionKey: Encryption.generateKey()
            };
            
            // Save user
            const success = DataStore.addUser(user);
            
            if (success) {
                // Log in the user
                DataStore.setCurrentUser(userId);
                
                // Show the app
                this.showApp(user);
            } else {
                alert('Registration failed. Please try again.');
            }
        } catch (error) {
            console.error('Registration error:', error);
            alert('An error occurred during registration');
        }
    },
    
    /**
     * Handle user logout
     */
    handleLogout: function() {
        DataStore.clearCurrentUser();
        this.showAuth();
    },
    
    /**
     * Show the authentication section
     */
    showAuth: function() {
        // Show auth section
        const authSection = document.getElementById('auth-section');
        authSection.classList.add('active');
        
        // Hide app section
        const appSection = document.getElementById('app-section');
        appSection.classList.remove('active');
    },
    
    /**
     * Show the main application after successful login
     * @param {Object} user - The logged in user
     */
    showApp: function(user) {
        // Hide auth section
        const authSection = document.getElementById('auth-section');
        authSection.classList.remove('active');
        
        // Apply role to body element for CSS targeting
        document.body.setAttribute('data-role', user.role);
        
        // Show app section
        const appSection = document.getElementById('app-section');
        appSection.classList.add('active');
        
        // Update user name in header with role badge
        const userNameElement = document.getElementById('user-name');
        if (userNameElement) {
            // Add role badge next to username
            const roleBadgeClass = `${user.role}-badge`;
            const roleText = user.role.charAt(0).toUpperCase() + user.role.slice(1);
            userNameElement.innerHTML = `${user.name} <span class="${roleBadgeClass}">${roleText}</span>`;
        }
        
        // Show/hide role-specific navigation links
        this.updateNavigation(user.role);
        
        // Initialize the main application
        App.init(user);
    },
    
    /**
     * Update navigation based on user role
     * @param {string} role - User role (patient, doctor, admin)
     */
    updateNavigation: function(role) {
        try {
            const navItems = document.querySelectorAll('nav ul li');
            
            // Define which views each role can access
            const allowedViews = {
                patient: ['dashboard', 'records', 'share', 'chatbot', 'settings'],
                doctor: ['dashboard', 'records', 'share', 'audit', 'chatbot', 'settings'],
                admin: ['dashboard', 'records', 'share', 'audit', 'chatbot', 'settings', 'users', 'system']
            };
            
            // Hide/show nav items based on role
            navItems.forEach(item => {
                const link = item.querySelector('.nav-link');
                if (link) {
                    const view = link.getAttribute('data-view');
                    
                    if (allowedViews[role] && allowedViews[role].includes(view)) {
                        item.style.display = 'block';
                    } else {
                        item.style.display = 'none';
                    }
                }
            });
            
            // Add role-specific navigation items if they don't exist
            if (role === 'doctor' && !document.querySelector('[data-view="patients"]')) {
                this.addDoctorNavItems();
            }
            
            if (role === 'admin' && !document.querySelector('[data-view="users"]')) {
                this.addAdminNavItems();
            }
        } catch (error) {
            console.error('Error updating navigation:', error);
        }
    },
    
    /**
     * Add doctor-specific navigation items
     */
    addDoctorNavItems: function() {
        const navList = document.querySelector('nav ul');
        if (!navList) return;
        
        // Add patients link after dashboard
        const dashboardItem = document.querySelector('[data-view="dashboard"]').parentNode;
        const patientsItem = document.createElement('li');
        patientsItem.className = 'doctor-only';
        patientsItem.innerHTML = `
            <a href="#" class="nav-link" data-view="patients">
                <i class="fas fa-user-injured"></i> My Patients
            </a>
        `;
        
        // Insert after dashboard
        if (dashboardItem.nextSibling) {
            navList.insertBefore(patientsItem, dashboardItem.nextSibling);
        } else {
            navList.appendChild(patientsItem);
        }
        
        // Add patients view section if it doesn't exist
        let patientsView = document.getElementById('patients-view');
        if (!patientsView) {
            const main = document.querySelector('main');
            if (main) {
                patientsView = document.createElement('section');
                patientsView.id = 'patients-view';
                patientsView.className = 'view';
                patientsView.innerHTML = `
                    <h2><i class="fas fa-user-injured"></i> My Patients</h2>
                    <div class="patient-list">
                        <div class="patient-list-header">
                            <h3>Patient Directory</h3>
                            <button class="btn secondary-btn"><i class="fas fa-plus"></i> Add Patient</button>
                        </div>
                        <div class="patient-item">
                            <div class="patient-avatar">JD</div>
                            <div class="patient-info">
                                <div class="patient-name">John Doe</div>
                                <div class="patient-details">Last visit: 05/15/2023 • 42 years old • 5 records</div>
                            </div>
                            <div class="patient-actions">
                                <button class="btn secondary-btn btn-sm">View Records</button>
                                <button class="btn secondary-btn btn-sm">Message</button>
                            </div>
                        </div>
                        <div class="patient-item">
                            <div class="patient-avatar">AS</div>
                            <div class="patient-info">
                                <div class="patient-name">Alice Smith</div>
                                <div class="patient-details">Last visit: 06/02/2023 • 35 years old • 3 records</div>
                            </div>
                            <div class="patient-actions">
                                <button class="btn secondary-btn btn-sm">View Records</button>
                                <button class="btn secondary-btn btn-sm">Message</button>
                            </div>
                        </div>
                        <div class="patient-item">
                            <div class="patient-avatar">RJ</div>
                            <div class="patient-info">
                                <div class="patient-name">Robert Johnson</div>
                                <div class="patient-details">Last visit: 05/28/2023 • 58 years old • 7 records</div>
                            </div>
                            <div class="patient-actions">
                                <button class="btn secondary-btn btn-sm">View Records</button>
                                <button class="btn secondary-btn btn-sm">Message</button>
                            </div>
                        </div>
                    </div>
                `;
                main.appendChild(patientsView);
            }
        }
        
        // Update event listeners
        patientsItem.querySelector('.nav-link').addEventListener('click', (e) => {
            e.preventDefault();
            App.navigateTo('patients');
        });
    },
    
    /**
     * Add admin-specific navigation items
     */
    addAdminNavItems: function() {
        const navList = document.querySelector('nav ul');
        if (!navList) return;
        
        // Add user management link before settings
        const settingsItem = document.querySelector('[data-view="settings"]').parentNode;
        const usersItem = document.createElement('li');
        usersItem.className = 'admin-only';
        usersItem.innerHTML = `
            <a href="#" class="nav-link" data-view="users">
                <i class="fas fa-users-cog"></i> User Management
            </a>
        `;
        
        // Add system stats link before settings
        const systemItem = document.createElement('li');
        systemItem.className = 'admin-only';
        systemItem.innerHTML = `
            <a href="#" class="nav-link" data-view="system">
                <i class="fas fa-server"></i> System
            </a>
        `;
        
        // Insert before settings
        navList.insertBefore(usersItem, settingsItem);
        navList.insertBefore(systemItem, settingsItem);
        
        // Update event listeners
        usersItem.querySelector('.nav-link').addEventListener('click', (e) => {
            e.preventDefault();
            App.navigateTo('users');
        });
        
        systemItem.querySelector('.nav-link').addEventListener('click', (e) => {
            e.preventDefault();
            App.navigateTo('system');
        });
    }
}; 