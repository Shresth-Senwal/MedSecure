/**
 * Data Storage module for MedSecure
 * 
 * Handles data persistence using localStorage.
 */

const DataStore = {
    // Storage keys
    KEYS: {
        USERS: 'medSecure_users',
        CURRENT_USER: 'medSecure_currentUser',
        RECORDS: 'medSecure_records',
        AUDIT_LOG: 'medSecure_auditLog'
    },
    
    /**
     * Initialize the data store
     */
    init: function() {
        // Create initial data if not exists
        if (!localStorage.getItem(this.KEYS.USERS)) {
            localStorage.setItem(this.KEYS.USERS, JSON.stringify([]));
        }
        
        if (!localStorage.getItem(this.KEYS.RECORDS)) {
            localStorage.setItem(this.KEYS.RECORDS, JSON.stringify([]));
        }
        
        if (!localStorage.getItem(this.KEYS.AUDIT_LOG)) {
            localStorage.setItem(this.KEYS.AUDIT_LOG, JSON.stringify([]));
        }
        
        console.log('DataStore initialized');
    },
    
    /**
     * Get all users
     * @returns {Array} Array of user objects
     */
    getUsers: function() {
        try {
            const usersJSON = localStorage.getItem(this.KEYS.USERS);
            return JSON.parse(usersJSON) || [];
        } catch (error) {
            console.error('Error getting users:', error);
            return [];
        }
    },
    
    /**
     * Get current user
     * @returns {Object|null} Current user object or null
     */
    getCurrentUser: function() {
        try {
            const userId = localStorage.getItem(this.KEYS.CURRENT_USER);
            if (!userId) return null;
            
            const users = this.getUsers();
            return users.find(user => user.id === userId) || null;
        } catch (error) {
            console.error('Error getting current user:', error);
            return null;
        }
    },
    
    /**
     * Set current user
     * @param {string} userId - ID of user to set as current
     */
    setCurrentUser: function(userId) {
        localStorage.setItem(this.KEYS.CURRENT_USER, userId);
    },
    
    /**
     * Clear current user (logout)
     */
    clearCurrentUser: function() {
        localStorage.removeItem(this.KEYS.CURRENT_USER);
    },
    
    /**
     * Add a new user
     * @param {Object} user - User object to add
     * @returns {boolean} Success status
     */
    addUser: function(user) {
        try {
            // Check if email already exists
            const users = this.getUsers();
            if (users.some(u => u.email === user.email)) {
                return false;
            }
            
            // Add user
            users.push(user);
            localStorage.setItem(this.KEYS.USERS, JSON.stringify(users));
            
            // Create demo data for new user
            this.createDemoDataForUser(user.id);
            
            return true;
        } catch (error) {
            console.error('Error adding user:', error);
            return false;
        }
    },
    
    /**
     * Create demo data for a new user
     * @param {string} userId - User ID to create data for
     */
    createDemoDataForUser: function(userId) {
        try {
            // Create sample records
            const records = this.getRecords() || [];
            
            // Add a few sample records
            const sampleRecords = [
                {
                    id: 'record_' + Date.now(),
                    userId: userId,
                    title: 'Annual Physical Results',
                    type: 'lab',
                    date: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 30 days ago
                    notes: 'Regular annual physical examination',
                    fileId: 'file_1',
                    createdAt: new Date().toISOString()
                },
                {
                    id: 'record_' + (Date.now() + 1),
                    userId: userId,
                    title: 'Blood Test Results',
                    type: 'lab',
                    date: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 15 days ago
                    notes: 'Routine blood work',
                    fileId: 'file_2',
                    createdAt: new Date().toISOString()
                },
                {
                    id: 'record_' + (Date.now() + 2),
                    userId: userId,
                    title: 'COVID-19 Vaccination',
                    type: 'prescription',
                    date: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 60 days ago
                    notes: 'COVID-19 vaccination record',
                    fileId: 'file_3',
                    createdAt: new Date().toISOString()
                }
            ];
            
            records.push(...sampleRecords);
            localStorage.setItem(this.KEYS.RECORDS, JSON.stringify(records));
            
            // Create sample audit log entries
            const now = Date.now();
            const auditEntries = [
                {
                    id: 'audit_' + now,
                    userId: userId,
                    eventType: 'LOGIN',
                    timestamp: new Date(now - 2 * 24 * 60 * 60 * 1000).toISOString(), // 2 days ago
                    ipAddress: '192.168.1.1',
                    status: 'SUCCESS'
                },
                {
                    id: 'audit_' + (now + 1),
                    userId: userId,
                    eventType: 'UPLOAD',
                    timestamp: new Date(now - 1.5 * 24 * 60 * 60 * 1000).toISOString(), // 1.5 days ago
                    ipAddress: '192.168.1.1',
                    status: 'SUCCESS',
                    data: { recordId: sampleRecords[0].id }
                }
            ];
            
            const auditLog = this.getAuditLog() || [];
            auditLog.push(...auditEntries);
            localStorage.setItem(this.KEYS.AUDIT_LOG, JSON.stringify(auditLog));
            
            console.log('Demo data created for user:', userId);
        } catch (error) {
            console.error('Error creating demo data:', error);
        }
    },
    
    /**
     * Get all records
     * @returns {Array} Array of record objects
     */
    getRecords: function() {
        try {
            const recordsJSON = localStorage.getItem(this.KEYS.RECORDS);
            return JSON.parse(recordsJSON) || [];
        } catch (error) {
            console.error('Error getting records:', error);
            return [];
        }
    },
    
    /**
     * Save a record, preventing duplicates
     * @param {Object} record - Record object to save
     * @returns {boolean} Success status
     */
    saveRecord: function(record) {
        try {
            const records = this.getRecords();
            
            // Check for duplicate by comparing properties
            const isDuplicate = records.some(r => 
                r.userId === record.userId && 
                r.title === record.title && 
                r.type === record.type && 
                r.date === record.date && 
                Math.abs(new Date(r.createdAt) - new Date(record.createdAt)) < 5000 // within 5 seconds
            );
            
            if (isDuplicate) {
                console.warn('Duplicate record detected, not saving:', record);
                return false;
            }
            
            // Add the record
            records.push(record);
            localStorage.setItem(this.KEYS.RECORDS, JSON.stringify(records));
            return true;
        } catch (error) {
            console.error('Error saving record:', error);
            return false;
        }
    },
    
    /**
     * Delete a record
     * @param {string} recordId - ID of record to delete
     * @returns {boolean} Success status
     */
    deleteRecord: function(recordId) {
        try {
            let records = this.getRecords();
            const initialLength = records.length;
            
            // Filter out the record to delete
            records = records.filter(record => record.id !== recordId);
            
            if (records.length === initialLength) {
                // Record wasn't found
                return false;
            }
            
            localStorage.setItem(this.KEYS.RECORDS, JSON.stringify(records));
            return true;
        } catch (error) {
            console.error('Error deleting record:', error);
            return false;
        }
    },
    
    /**
     * Get audit log entries
     * @returns {Array} Array of audit log objects
     */
    getAuditLog: function() {
        try {
            const auditLogJSON = localStorage.getItem(this.KEYS.AUDIT_LOG);
            return JSON.parse(auditLogJSON) || [];
        } catch (error) {
            console.error('Error getting audit log:', error);
            return [];
        }
    }
}; 