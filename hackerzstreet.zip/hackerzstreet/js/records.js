/**
 * Records module for MedSecure
 * 
 * Handles medical record creation, viewing, and sharing.
 */

const Records = {
    /**
     * Initialize the records module
     * @param {Object} user - The current user
     */
    init: function(user) {
        this.currentUser = user;
        
        // Load records
        this.loadUserRecords();
        this.loadSharedRecords();
        
        // Update dashboard counts
        this.updateDashboardCounts();
        
        // Bind events
        this.bindEvents();
        
        // Sample prescription images
        this.prescriptionImages = {
            'file_1': 'https://via.placeholder.com/800x1000/e2f3f5/333333?text=Annual+Physical+Results',
            'file_2': 'https://via.placeholder.com/800x1000/f8f3d4/333333?text=Blood+Test+Results',
            'file_3': 'https://via.placeholder.com/800x1000/ffcfdf/333333?text=COVID-19+Vaccination+Record',
        };
    },
    
    /**
     * Bind event listeners for record functionality
     */
    bindEvents: function() {
        // Upload record button
        const uploadRecordBtn = document.getElementById('upload-record-btn');
        if (uploadRecordBtn) {
            uploadRecordBtn.addEventListener('click', () => {
                this.showUploadModal();
            });
        }
        
        // Close modal buttons
        const closeButtons = document.querySelectorAll('.modal .close');
        closeButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                const modal = btn.closest('.modal');
                modal.style.display = 'none';
            });
        });
        
        // Upload form submission
        const uploadForm = document.getElementById('upload-form');
        if (uploadForm) {
            uploadForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleRecordUpload();
            });
        }
        
        // Add file input preview functionality
        const fileInput = document.getElementById('record-file');
        if (fileInput) {
            this.setupFilePreview(fileInput);
        }
        
        // Share form submission
        const shareForm = document.getElementById('share-form');
        if (shareForm) {
            shareForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleRecordShare();
            });
        }
        
        // Dashboard shortcuts
        const viewRecordsBtn = document.querySelector('[data-action="view-records"]');
        if (viewRecordsBtn) {
            viewRecordsBtn.addEventListener('click', () => {
                App.navigateTo('records');
            });
        }
        
        const viewSharedBtn = document.querySelector('[data-action="view-shared"]');
        if (viewSharedBtn) {
            viewSharedBtn.addEventListener('click', () => {
                App.navigateTo('share');
            });
        }
        
        // Add prescription modal close functionality
        document.addEventListener('click', (e) => {
            const modal = document.querySelector('.prescription-modal');
            if (modal && (e.target === modal || e.target.classList.contains('close-prescription-modal'))) {
                modal.classList.remove('active');
            }
        });
    },
    
    /**
     * Show the upload modal
     */
    showUploadModal: function() {
        const modal = document.getElementById('upload-modal');
        modal.style.display = 'block';
        
        // Set default date to today
        const dateInput = document.getElementById('record-date');
        dateInput.value = new Date().toISOString().split('T')[0];
    },
    
    /**
     * Handle record upload form submission
     */
    handleRecordUpload: function() {
        const titleInput = document.getElementById('record-title');
        const typeInput = document.getElementById('record-type');
        const dateInput = document.getElementById('record-date');
        const fileInput = document.getElementById('record-file');
        const notesInput = document.getElementById('record-notes');
        
        const title = titleInput.value.trim();
        const type = typeInput.value;
        const date = dateInput.value;
        const notes = notesInput.value.trim();
        
        // Validate inputs
        if (!title || !date) {
            App.showToast('error', 'Missing Information', 'Please fill in all required fields');
            return;
        }
        
        // Get file data if available
        if (fileInput.files && fileInput.files[0]) {
            const file = fileInput.files[0];
            
            // Check file size
            if (file.size > 10 * 1024 * 1024) { // 10MB limit
                App.showToast('error', 'File Too Large', 'The maximum file size is 10MB.');
                return;
            }
            
            // Check file type
            const isImage = file.type.startsWith('image/');
            const isPDF = file.type === 'application/pdf';
            const isDoc = file.type.includes('word') || file.name.endsWith('.doc') || file.name.endsWith('.docx');
            
            if (!isImage && !isPDF && !isDoc) {
                App.showToast('error', 'Invalid File Type', 'Please upload an image, PDF, or document file.');
                return;
            }
            
            // Process the file
            const reader = new FileReader();
            reader.onload = (e) => {
                const fileUrl = e.target.result;
                const fileMetadata = {
                    name: file.name,
                    type: file.type,
                    size: file.size,
                    isImage: isImage
                };
                this.finishRecordUpload(title, type, date, notes, fileUrl, fileMetadata);
            };
            reader.readAsDataURL(file);
        } else {
            // No file, create a placeholder
            const fileUrl = `https://via.placeholder.com/800x1000/${this.getRandomColor()}/333333?text=${encodeURIComponent(title)}`;
            const fileMetadata = {
                name: 'placeholder.png',
                type: 'image/png',
                size: 0,
                isImage: true,
                isPlaceholder: true
            };
            this.finishRecordUpload(title, type, date, notes, fileUrl, fileMetadata);
        }
    },
    
    /**
     * Finish record upload with file URL
     */
    finishRecordUpload: function(title, type, date, notes, fileUrl, fileMetadata) {
        // Create record object
        const fileId = 'file_' + Date.now();
        const recordId = 'record_' + Date.now();
        const record = {
            id: recordId,
            userId: this.currentUser.id,
            title: title,
            type: type,
            date: date,
            notes: notes,
            fileId: fileId,
            fileMetadata: fileMetadata,
            createdAt: new Date().toISOString()
        };
        
        // Save record using DataStore method (prevents duplicates)
        const saved = DataStore.saveRecord(record);
        
        // If saved successfully, store the image URL and log the event
        if (saved) {
            // Store the image URL
            this.prescriptionImages[fileId] = fileUrl;
            
            // Log upload event
            AuditLogger.logSystemEvent(this.currentUser.id, 'UPLOAD', {
                recordId: record.id,
                recordType: record.type,
                fileType: fileMetadata.type
            });
            
            // Show success message
            App.showToast('success', 'Record Uploaded', 'Your medical record has been successfully uploaded.');
        } else {
            // Show error for duplicate
            App.showToast('warning', 'Duplicate Record', 'This appears to be a duplicate record.');
        }
        
        // Close modal
        const modal = document.getElementById('upload-modal');
        modal.style.display = 'none';
        
        // Reset form
        document.getElementById('upload-form').reset();
        
        // Reset file preview
        const previewContainer = document.querySelector('.file-preview');
        if (previewContainer) {
            previewContainer.style.display = 'none';
            const previewContentContainer = document.querySelector('.preview-container');
            if (previewContentContainer) {
                previewContentContainer.innerHTML = '';
            }
        }
        
        // Refresh records list
        this.loadUserRecords();
        this.updateDashboardCounts();
    },
    
    /**
     * View a record
     * @param {string} recordId - ID of the record to view
     */
    viewRecord: function(recordId) {
        // Get record from storage
        const allRecords = DataStore.getRecords() || [];
        const record = allRecords.find(r => r.id === recordId);
        
        if (!record) {
            alert('Record not found');
            return;
        }
        
        // Log view event
        AuditLogger.logSystemEvent(this.currentUser.id, 'VIEW', {
            recordId: record.id,
            recordType: record.type
        });
        
        // Display the record details in the enhanced viewer modal
        this.viewRecordInModal(record);
    },
    
    /**
     * View any record type in a modal with image support
     * @param {Object} record - The record to view
     */
    viewRecordInModal: function(record) {
        // Check if modal exists, create if not
        let modal = document.querySelector('.record-view-modal');
        
        if (!modal) {
            // Create modal element
            modal = document.createElement('div');
            modal.className = 'record-view-modal';
            modal.innerHTML = `
                <div class="record-modal-content">
                    <span class="close close-record-modal">&times;</span>
                    <h2 class="record-modal-title">Medical Record Details</h2>
                    <div class="record-modal-type-badge"></div>
                    
                    <div class="record-image-container">
                        <div class="file-display-area">
                            <!-- Content will be dynamically inserted based on file type -->
                        </div>
                        <div class="image-controls">
                            <button class="btn secondary-btn image-zoom-in"><i class="fas fa-search-plus"></i></button>
                            <button class="btn secondary-btn image-zoom-out"><i class="fas fa-search-minus"></i></button>
                            <button class="btn secondary-btn image-reset"><i class="fas fa-undo"></i></button>
                        </div>
                    </div>
                    
                    <div class="record-details">
                        <div class="record-info">
                            <div>
                                <div class="label">Title</div>
                                <div class="value record-title"></div>
                            </div>
                            <div>
                                <div class="label">Type</div>
                                <div class="value record-type-label"></div>
                            </div>
                            <div>
                                <div class="label">Date</div>
                                <div class="value record-date"></div>
                            </div>
                            <div>
                                <div class="label">Record ID</div>
                                <div class="value record-id"></div>
                            </div>
                            <div>
                                <div class="label">Created</div>
                                <div class="value record-created"></div>
                            </div>
                        </div>
                        <div class="file-metadata">
                            <div class="label">File Information</div>
                            <div class="file-metadata-content"></div>
                        </div>
                        <div style="margin-top: 1rem;">
                            <div class="label">Notes</div>
                            <div class="value record-notes"></div>
                        </div>
                    </div>
                    <div class="record-actions">
                        <button class="btn secondary-btn close-record-modal">Close</button>
                        <button class="btn primary-btn download-record">Download</button>
                        <button class="btn secondary-btn share-record">Share</button>
                        <button class="btn danger-btn delete-record">Delete</button>
                    </div>
                </div>
            `;
            document.body.appendChild(modal);
            
            // Add zoom functionality
            const zoomIn = modal.querySelector('.image-zoom-in');
            const zoomOut = modal.querySelector('.image-zoom-out');
            const resetZoom = modal.querySelector('.image-reset');
            
            let scale = 1;
            
            zoomIn.addEventListener('click', () => {
                scale *= 1.2;
                const image = modal.querySelector('.record-image');
                if (image) {
                    image.style.transform = `scale(${scale})`;
                }
            });
            
            zoomOut.addEventListener('click', () => {
                scale *= 0.8;
                const image = modal.querySelector('.record-image');
                if (image) {
                    image.style.transform = `scale(${scale})`;
                }
            });
            
            resetZoom.addEventListener('click', () => {
                scale = 1;
                const image = modal.querySelector('.record-image');
                if (image) {
                    image.style.transform = `scale(${scale})`;
                }
            });
            
            // Add download button functionality
            modal.querySelector('.download-record').addEventListener('click', () => {
                const recordId = modal.querySelector('.record-id').textContent;
                this.downloadRecord(recordId);
            });
            
            // Add share button functionality
            modal.querySelector('.share-record').addEventListener('click', () => {
                const recordId = modal.querySelector('.record-id').textContent;
                this.prepareRecordForSharing(recordId);
                modal.classList.remove('active');
            });
            
            // Add delete button functionality
            modal.querySelector('.delete-record').addEventListener('click', () => {
                const recordId = modal.querySelector('.record-id').textContent;
                if (confirm('Are you sure you want to delete this record? This action cannot be undone.')) {
                    this.deleteRecord(recordId);
                    modal.classList.remove('active');
                }
            });
            
            // Add close functionality
            const closeButtons = modal.querySelectorAll('.close-record-modal');
            closeButtons.forEach(btn => {
                btn.addEventListener('click', () => {
                    modal.classList.remove('active');
                    // Reset zoom when closing
                    scale = 1;
                    const image = modal.querySelector('.record-image');
                    if (image) {
                        image.style.transform = `scale(${scale})`;
                    }
                });
            });
            
            // Close on click outside of content
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    modal.classList.remove('active');
                    // Reset zoom when closing
                    scale = 1;
                    const image = modal.querySelector('.record-image');
                    if (image) {
                        image.style.transform = `scale(${scale})`;
                    }
                }
            });
        }
        
        // Update modal content
        modal.querySelector('.record-modal-title').textContent = 
            record.type === 'prescription' ? 'Prescription Details' : 
            record.type === 'lab' ? 'Lab Result Details' : 
            record.type === 'imaging' ? 'Medical Imaging Details' : 
            record.type === 'clinical' ? 'Clinical Notes Details' : 
            'Medical Record Details';
        
        // Update type badge
        const typeBadge = modal.querySelector('.record-modal-type-badge');
        typeBadge.textContent = this.getTypeLabel(record.type);
        typeBadge.className = 'record-modal-type-badge ' + record.type;
        
        // Get file display area
        const fileDisplayArea = modal.querySelector('.file-display-area');
        fileDisplayArea.innerHTML = ''; // Clear previous content
        
        // Get image controls
        const imageControls = modal.querySelector('.image-controls');
        
        // Get file metadata
        const fileMetadata = record.fileMetadata || {
            name: 'Unknown file',
            type: 'unknown',
            size: 0,
            isImage: true,
            isPlaceholder: true
        };
        
        // Update file metadata display
        const fileMetadataContent = modal.querySelector('.file-metadata-content');
        fileMetadataContent.innerHTML = `
            <p><strong>Filename:</strong> ${fileMetadata.name || 'Unknown'}</p>
            <p><strong>File type:</strong> ${fileMetadata.type || 'Unknown'}</p>
            <p><strong>File size:</strong> ${this.formatFileSize(fileMetadata.size || 0)}</p>
        `;
        
        // Get image URL or placeholder
        let fileUrl;
        
        if (record.fileId && this.prescriptionImages[record.fileId]) {
            fileUrl = this.prescriptionImages[record.fileId];
        } else {
            // Use placeholder
            fileUrl = `https://via.placeholder.com/800x1000/${this.getRandomColor()}/333333?text=${encodeURIComponent(record.title)}`;
        }
        
        // Display content based on file type
        if (fileMetadata.isImage) {
            // Create image element
            const img = document.createElement('img');
            img.className = 'record-image';
            img.src = fileUrl;
            img.alt = record.title;
            fileDisplayArea.appendChild(img);
            
            // Show image controls
            imageControls.style.display = 'flex';
        } else if (fileMetadata.type && fileMetadata.type.includes('pdf')) {
            // Create PDF embed element (note: in a real app, might need more robust handling)
            fileDisplayArea.innerHTML = `
                <div class="pdf-container">
                    <div class="pdf-icon"><i class="fas fa-file-pdf"></i></div>
                    <p>PDF document - use download button to view</p>
                </div>
            `;
            // Hide image controls
            imageControls.style.display = 'none';
        } else {
            // Display generic file icon based on type
            let iconClass = 'fa-file';
            if (fileMetadata.type && fileMetadata.type.includes('word')) {
                iconClass = 'fa-file-word';
            } else if (fileMetadata.type && fileMetadata.type.includes('text')) {
                iconClass = 'fa-file-alt';
            }
            
            fileDisplayArea.innerHTML = `
                <div class="file-icon-container">
                    <div class="file-icon"><i class="fas ${iconClass}"></i></div>
                    <p>${fileMetadata.name || 'Document'}</p>
                </div>
            `;
            // Hide image controls
            imageControls.style.display = 'none';
        }
        
        // Update record details
        modal.querySelector('.record-title').textContent = record.title;
        modal.querySelector('.record-type-label').textContent = this.getTypeLabel(record.type);
        modal.querySelector('.record-date').textContent = record.date;
        modal.querySelector('.record-id').textContent = record.id;
        modal.querySelector('.record-created').textContent = new Date(record.createdAt).toLocaleString();
        modal.querySelector('.record-notes').textContent = record.notes || 'No notes provided';
        
        // Show modal
        modal.classList.add('active');
    },
    
    /**
     * Download a record
     * @param {string} recordId - ID of the record to download
     */
    downloadRecord: function(recordId) {
        // Get record from storage
        const allRecords = DataStore.getRecords() || [];
        const record = allRecords.find(r => r.id === recordId);
        
        if (!record) {
            App.showToast('error', 'Download Failed', 'Record not found.');
            return;
        }
        
        // Start download process
        App.showToast('info', 'Download Initiated', 'Preparing file...');
        
        // Get the file URL
        let fileUrl = '';
        if (record.fileId && this.prescriptionImages[record.fileId]) {
            fileUrl = this.prescriptionImages[record.fileId];
        } else {
            // Create a placeholder if no file
            fileUrl = `https://via.placeholder.com/800x1000/${this.getRandomColor()}/333333?text=${encodeURIComponent(record.title)}`;
        }
        
        // Create filename based on record data
        const fileExtension = this.getFileExtension(record);
        const fileName = `${record.title.replace(/\s+/g, '_')}_${record.date}${fileExtension}`;
        
        // Create an anchor element and trigger download
        const downloadLink = document.createElement('a');
        downloadLink.href = fileUrl;
        downloadLink.download = fileName;
        
        // For data URLs, we can download directly
        document.body.appendChild(downloadLink);
        downloadLink.click();
        document.body.removeChild(downloadLink);
        
        // Log download event
        AuditLogger.logSystemEvent(this.currentUser.id, 'DOWNLOAD', {
            recordId: record.id,
            recordType: record.type
        });
        
        // Show success message
        setTimeout(() => {
            App.showToast('success', 'Download Complete', `${fileName} has been downloaded.`);
        }, 1000);
    },
    
    /**
     * Get file extension based on record metadata
     * @param {Object} record - The record object
     * @returns {string} File extension including the dot
     */
    getFileExtension: function(record) {
        if (!record.fileMetadata) return '.png';
        
        const fileType = record.fileMetadata.type;
        if (fileType.includes('jpeg') || fileType.includes('jpg')) return '.jpg';
        if (fileType.includes('png')) return '.png';
        if (fileType.includes('pdf')) return '.pdf';
        if (fileType.includes('word') || fileType.includes('doc')) return '.docx';
        
        // Default to png for unknown types
        return '.png';
    },
    
    /**
     * Delete a record
     * @param {string} recordId - ID of the record to delete
     */
    deleteRecord: function(recordId) {
        // First get the record for logging
        const allRecords = DataStore.getRecords() || [];
        const record = allRecords.find(r => r.id === recordId);
        
        if (!record) {
            alert('Record not found');
            return false;
        }
        
        // Use DataStore to delete the record
        const deleted = DataStore.deleteRecord(recordId);
        
        if (deleted) {
            // Log delete event
            AuditLogger.logSystemEvent(this.currentUser.id, 'DELETE', {
                recordId: recordId,
                recordType: record.type
            });
            
            // Refresh records list
            this.loadUserRecords();
            this.updateDashboardCounts();
            
            // Show success message
            App.showToast('success', 'Record Deleted', 'The record has been deleted successfully.');
            
            return true;
        } else {
            App.showToast('error', 'Deletion Failed', 'The record could not be deleted.');
            return false;
        }
    },
    
    /**
     * Get a random color for placeholder images
     * @returns {string} Random color hex (without #)
     */
    getRandomColor: function() {
        const colors = [
            'e2f3f5', 'f8f3d4', 'ffcfdf', 'd8e3e7', 
            'f6f6f6', 'e4f9f5', 'f4f9f9', 'f8f8f8'
        ];
        return colors[Math.floor(Math.random() * colors.length)];
    },
    
    /**
     * Prepare a record for sharing
     * @param {string} recordId - ID of the record to share
     */
    prepareRecordForSharing: function(recordId) {
        // Get record from storage
        const allRecords = DataStore.getRecords() || [];
        const record = allRecords.find(r => r.id === recordId);
        
        if (!record) {
            App.showToast('error', 'Sharing Failed', 'Record not found.');
            return;
        }
        
        // Navigate to share view
        App.navigateTo('share');
        
        // Pre-select the record in the sharing form
        this.preSelectRecordForSharing(record);
        
        // Show toast to inform user
        App.showToast('info', 'Ready to Share', `${record.title} is ready to be shared.`);
    },
    
    /**
     * Pre-select a record in the sharing form
     * @param {Object} record - The record to pre-select
     */
    preSelectRecordForSharing: function(record) {
        // This would be implemented in a real app
        // For this demo, we'll highlight the record in the sharable records list
        const recordItems = document.querySelectorAll('#sharable-records .record-card');
        
        recordItems.forEach(item => {
            if (item.getAttribute('data-id') === record.id) {
                item.classList.add('selected-for-sharing');
                item.scrollIntoView({ behavior: 'smooth', block: 'center' });
            } else {
                item.classList.remove('selected-for-sharing');
            }
        });
        
        // Scroll to share form after selecting the record
        const shareForm = document.querySelector('.share-form');
        if (shareForm) {
            setTimeout(() => {
                shareForm.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }, 500);
        }
    },
    
    /**
     * Handle record sharing form submission
     */
    handleRecordShare: function() {
        const recipientInput = document.getElementById('recipient-email');
        const accessLevel = document.getElementById('access-level');
        const expirationDate = document.getElementById('expiration-date');
        const shareNotes = document.getElementById('share-notes');
        
        const recipient = recipientInput.value.trim();
        
        // Validate inputs
        if (!recipient) {
            App.showToast('error', 'Validation Error', 'Please provide a recipient email.');
            recipientInput.focus();
            return;
        }
        
        // Check if any records are selected
        const selectedRecords = document.querySelectorAll('#sharable-records .record-card.selected-for-sharing');
        if (selectedRecords.length === 0) {
            App.showToast('warning', 'No Records Selected', 'Please select at least one record to share.');
            return;
        }
        
        // In a real app, this would create sharing permissions
        // For this demo, we'll update the UI to show success
        
        // Show sharing in progress
        App.showToast('info', 'Sharing in Progress', 'Creating secure sharing links...');
        
        // Get selected record IDs
        const recordIds = Array.from(selectedRecords).map(card => card.getAttribute('data-id'));
        
        // Log share event for each record
        recordIds.forEach(recordId => {
            AuditLogger.logSystemEvent(this.currentUser.id, 'SHARE', {
                recordId: recordId,
                recipient: recipient,
                accessLevel: accessLevel.value,
                expirationDate: expirationDate.value
            });
        });
        
        // Update UI to show the newly shared records in the history
        this.updateSharedHistory(recordIds, recipient, expirationDate.value, accessLevel.value);
        
        // Reset form
        setTimeout(() => {
            recipientInput.value = '';
            shareNotes.value = '';
            
            // Set expiration date to 7 days from now by default
            const nextWeek = new Date();
            nextWeek.setDate(nextWeek.getDate() + 7);
            expirationDate.value = nextWeek.toISOString().split('T')[0];
            
            // Clear selection
            selectedRecords.forEach(card => {
                card.classList.remove('selected-for-sharing');
            });
            
            // Show success message
            App.showToast('success', 'Records Shared', `${recordIds.length} record(s) shared with ${recipient}.`);
        }, 1500);
    },
    
    /**
     * Update the shared history table with new entries
     * @param {Array} recordIds - Array of shared record IDs
     * @param {string} recipient - Email of the recipient
     * @param {string} expirationDate - When the sharing expires
     * @param {string} accessLevel - The access level granted
     */
    updateSharedHistory: function(recordIds, recipient, expirationDate, accessLevel) {
        try {
            // Get the shared history container
            const sharedHistoryBody = document.getElementById('shared-history');
            if (!sharedHistoryBody) return;
            
            // Clear the "no history" row if present
            const emptyRow = sharedHistoryBody.querySelector('.empty-state');
            if (emptyRow) {
                sharedHistoryBody.innerHTML = '';
            }
            
            // Get all records
            const allRecords = DataStore.getRecords() || [];
            
            // Add new rows for each shared record
            recordIds.forEach(recordId => {
                const record = allRecords.find(r => r.id === recordId);
                if (!record) return;
                
                const row = document.createElement('tr');
                const today = new Date();
                row.innerHTML = `
                    <td>${record.title}</td>
                    <td>${recipient}</td>
                    <td>${today.toLocaleDateString()}</td>
                    <td>${new Date(expirationDate).toLocaleDateString()}</td>
                    <td><span class="status-active">Active</span></td>
                    <td>
                        <button class="btn secondary-btn btn-sm revoke-share-btn" data-record-id="${recordId}" data-recipient="${recipient}">
                            <i class="fas fa-ban"></i> Revoke
                        </button>
                    </td>
                `;
                
                // Add to the top of the table
                if (sharedHistoryBody.firstChild) {
                    sharedHistoryBody.insertBefore(row, sharedHistoryBody.firstChild);
                } else {
                    sharedHistoryBody.appendChild(row);
                }
                
                // Add event listener to revoke button
                const revokeBtn = row.querySelector('.revoke-share-btn');
                if (revokeBtn) {
                    revokeBtn.addEventListener('click', (e) => {
                        e.preventDefault();
                        this.revokeSharing(recordId, recipient);
                        row.querySelector('.status-active').className = 'status-revoked';
                        row.querySelector('.status-revoked').textContent = 'Revoked';
                        revokeBtn.disabled = true;
                        App.showToast('info', 'Access Revoked', `Revoked access for ${recipient}.`);
                    });
                }
            });
        } catch (error) {
            console.error('Error updating shared history:', error);
        }
    },
    
    /**
     * Revoke sharing for a record
     * @param {string} recordId - ID of the record
     * @param {string} recipient - Email of the recipient
     */
    revokeSharing: function(recordId, recipient) {
        // In a real app, this would update permissions in the database
        // For this demo, we just log the event
        AuditLogger.logSystemEvent(this.currentUser.id, 'REVOKE_SHARE', {
            recordId: recordId,
            recipient: recipient
        });
    },
    
    /**
     * Load user's medical records
     */
    loadUserRecords: function() {
        try {
            // Get all records
            const allRecords = DataStore.getRecords() || [];
            
            // Filter records for current user
            const userRecords = allRecords.filter(record => record.userId === this.currentUser.id);
            
            // Get records list container
            const recordsList = document.getElementById('user-records');
            
            if (userRecords.length === 0) {
                // Show empty state
                recordsList.innerHTML = `<p class="empty-state">No records found. Upload your first medical record.</p>`;
                return;
            }
            
            // Build records HTML
            let recordsHTML = '';
            userRecords.forEach(record => {
                recordsHTML += this.createRecordCard(record);
            });
            
            // Update records list
            recordsList.innerHTML = recordsHTML;
            
            // Attach event listeners to record cards
            this.attachRecordCardEvents();
        } catch (error) {
            console.error('Error loading user records:', error);
        }
    },
    
    /**
     * Format file size in human-readable format
     * @param {number} bytes - File size in bytes
     * @returns {string} Formatted file size
     */
    formatFileSize: function(bytes) {
        if (bytes < 1024) return bytes + ' bytes';
        if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + ' KB';
        if (bytes < 1024 * 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
        return (bytes / (1024 * 1024 * 1024)).toFixed(2) + ' GB';
    },
    
    /**
     * Load records shared with the current user
     */
    loadSharedRecords: function() {
        // For demo purposes, we'll just simulate this
        const sharedCount = document.getElementById('shared-count');
        if (sharedCount) {
            sharedCount.textContent = '2';
        }
    },
    
    /**
     * Update dashboard counts
     */
    updateDashboardCounts: function() {
        try {
            // Get all records
            const allRecords = DataStore.getRecords() || [];
            
            // Filter records for current user
            const userRecords = allRecords.filter(record => record.userId === this.currentUser.id);
            
            // Update record count display
            const recordsCount = document.getElementById('records-count');
            if (recordsCount) {
                recordsCount.textContent = userRecords.length.toString();
            }
        } catch (error) {
            console.error('Error updating dashboard counts:', error);
        }
    },
    
    /**
     * Create HTML for a record card
     * @param {Object} record - The record to create a card for
     * @returns {string} HTML string for the record card
     */
    createRecordCard: function(record) {
        return `
            <div class="record-card" data-id="${record.id}">
                <div class="record-type ${record.type}">${this.getTypeLabel(record.type)}</div>
                <h3 class="record-title">${record.title}</h3>
                <div class="record-date">Date: ${record.date}</div>
                <p class="record-notes">${record.notes || 'No notes provided'}</p>
                <div class="record-actions">
                    <button class="btn secondary-btn view-record-btn" data-id="${record.id}">View</button>
                    <button class="btn secondary-btn share-record-btn" data-id="${record.id}">Share</button>
                </div>
            </div>
        `;
    },
    
    /**
     * Get human-readable label for record type
     * @param {string} type - Record type code
     * @returns {string} Human-readable type label
     */
    getTypeLabel: function(type) {
        const types = {
            'lab': 'Lab Result',
            'prescription': 'Prescription',
            'imaging': 'Imaging',
            'clinical': 'Clinical Note',
            'other': 'Other'
        };
        
        return types[type] || 'Unknown';
    },
    
    /**
     * Attach event listeners to record cards
     */
    attachRecordCardEvents: function() {
        const recordCards = document.querySelectorAll('.record-card');
        
        recordCards.forEach(card => {
            const recordId = card.getAttribute('data-id');
            
            const viewBtn = card.querySelector('.view-record-btn');
            viewBtn.addEventListener('click', () => {
                this.viewRecord(recordId);
            });
            
            const shareBtn = card.querySelector('.share-record-btn');
            shareBtn.addEventListener('click', () => {
                this.prepareRecordForSharing(recordId);
            });
        });
    },
    
    /**
     * Setup file upload preview
     * @param {HTMLElement} fileInput - File input element
     */
    setupFilePreview: function(fileInput) {
        // Get the existing preview container
        const previewContainer = document.querySelector('.file-preview');
        const previewContentContainer = document.querySelector('.preview-container');
        
        if (!previewContainer || !previewContentContainer) return;
        
        // Add file change listener
        fileInput.addEventListener('change', function() {
            // Clear previous preview
            previewContentContainer.innerHTML = '';
            
            if (this.files && this.files[0]) {
                const file = this.files[0];
                const reader = new FileReader();
                
                // Show file info
                const fileInfo = document.createElement('div');
                fileInfo.className = 'file-info';
                fileInfo.innerHTML = `
                    <p><strong>File Name:</strong> ${file.name}</p>
                    <p><strong>File Size:</strong> ${Records.formatFileSize(file.size)}</p>
                    <p><strong>File Type:</strong> ${file.type || 'Unknown'}</p>
                `;
                previewContentContainer.appendChild(fileInfo);
                
                // Check if it's an image file
                const isImage = file.type.startsWith('image/');
                
                if (isImage) {
                    reader.onload = function(e) {
                        // Create image preview
                        const previewImage = document.createElement('img');
                        previewImage.className = 'preview-image';
                        previewImage.src = e.target.result;
                        previewContentContainer.appendChild(previewImage);
                        
                        // Store in preview data to use later
                        fileInput.dataset.previewUrl = e.target.result;
                    };
                    reader.readAsDataURL(file);
                } else {
                    // For non-image files, show a generic icon
                    const fileIcon = document.createElement('div');
                    fileIcon.className = 'file-icon';
                    
                    if (file.type.includes('pdf')) {
                        fileIcon.innerHTML = '<i class="fas fa-file-pdf"></i>';
                    } else if (file.type.includes('word') || file.name.endsWith('.doc') || file.name.endsWith('.docx')) {
                        fileIcon.innerHTML = '<i class="fas fa-file-word"></i>';
                    } else {
                        fileIcon.innerHTML = '<i class="fas fa-file"></i>';
                    }
                    
                    previewContentContainer.appendChild(fileIcon);
                }
                
                previewContainer.style.display = 'block';
            } else {
                previewContainer.style.display = 'none';
            }
        });
        
        // Add drag and drop functionality to the upload area
        const uploadContainer = fileInput.closest('.file-upload-container');
        
        if (uploadContainer) {
            ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
                uploadContainer.addEventListener(eventName, preventDefaults, false);
            });
            
            function preventDefaults(e) {
                e.preventDefault();
                e.stopPropagation();
            }
            
            ['dragenter', 'dragover'].forEach(eventName => {
                uploadContainer.addEventListener(eventName, () => {
                    uploadContainer.classList.add('highlight');
                }, false);
            });
            
            ['dragleave', 'drop'].forEach(eventName => {
                uploadContainer.addEventListener(eventName, () => {
                    uploadContainer.classList.remove('highlight');
                }, false);
            });
            
            uploadContainer.addEventListener('drop', (e) => {
                const dt = e.dataTransfer;
                const files = dt.files;
                
                if (files.length) {
                    fileInput.files = files;
                    // Trigger change event
                    const event = new Event('change');
                    fileInput.dispatchEvent(event);
                }
            }, false);
        }
    }
}; 